-- Loco Motive --

Loco Motive is a murder mystery-comedy, full of deadly surprises, larger than life characters and yes, the occasional blood fountain!

Mr. Arthur Ackerman finds himself in the personal employ of Lady Unterwald, an eccentric heiress of the Wald-Bahn rail company.

On the verge of a landmark speech, you've been summoned to make a last minute amendment to her Will - aboard her flagship luxury train, The Reuss Express.

Little does Arthur know, he's about to become embroiled in a murder, a mystery and worst of all... an adventure!


INSTRUCTIONS

	- Click ground to walk, and objects/characters to interact.
	- Move your mouse to the top of screen to open your inventory
	- Equip items by clicking them. 
	- Use an equipped item by clicking it on an object or character.
	- Combine items in your inventory by using one on the other.
	- Right Click, or Click empty space to unequip the current item.

CREDITS:
	- Adam Riches (@Supernorn) - Design, Story, Art, Sound
	- Joseph Riches (@GameDevJoe) - Design, Story, Code
	- Angelo 't3nshi' Di Rosa (@_t3nshi) - Additional Art
	- Paul Zimmermann (@Pzcomposer) - Music


CREATED WITH POWERQUEST
	A 2d adventure game tool for Unity made by Dave Lloyd (@DuzzOnDrums)
	https://powerhoof.itch.io/powerquest

